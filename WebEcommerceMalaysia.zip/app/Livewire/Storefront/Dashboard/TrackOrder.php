<?php

namespace App\Livewire\Storefront\Dashboard;

use Livewire\Component;
use App\Models\Order;
use App\Services\MyParcelService;
use Illuminate\Support\Facades\Log;

class TrackOrder extends Component
{
    public Order $order;
    public $trackingData = [];
    public $isLoading = true;
    public $error = null;

    public function mount(Order $order)
    {
        $this->order = $order;

        if (auth()->check()) {
            if ($order->user_id !== auth()->id()) {
                abort(403);
            }
        } else {
            // If guest, verify session
            if (session('last_order_id') !== $order->id) {
                abort(403);
            }
        }

        $this->trackingData = [];
        $this->fetchTracking();
    }

    public function fetchTracking()
    {
        if (empty($this->order->tracking_no) || str_starts_with($this->order->tracking_no, 'ORD-')) {
            $this->error = __('No valid tracking number available for this order.');
            $this->isLoading = false;
            return;
        }

        try {
            $myParcel = app(MyParcelService::class);
            $response = $myParcel->trace($this->order->tracking_no);

            if (isset($response['status']) && $response['status'] == 'success' && !empty($response['data'][0]['tracker'])) {
                $this->trackingData = $response['data'][0]['tracker'];
            } else {
                $this->error = __('Unable to fetch tracking data at the moment.');
            }
        } catch (\Exception $e) {
            Log::error('MyParcel Trace Error: ' . $e->getMessage());
            $this->error = __('Tracking information is currently unavailable.');
        }

        $this->isLoading = false;
    }

    public function render()
    {
        return view('livewire.storefront.dashboard.track-order')
            ->extends('layouts.storefront')
            ->section('content');
    }
}
