<?php

namespace App\Livewire\Storefront\Dashboard;

use Livewire\Component;

class LoyaltyView extends Component
{
    public function render()
    {
        $user = auth()->user();
        
        // Load loyalty points and referrals
        $user->loadMissing(['loyaltyPoints' => function ($q) {
            $q->orderBy('created_at', 'desc');
        }, 'referralsMade.referee']);

        $totalPoints = $user->total_points;
        $referralLink = route('register', ['ref' => $user->referral_code]);

        return view('livewire.storefront.dashboard.loyalty-view', compact('user', 'totalPoints', 'referralLink'))
            ->extends('components.dashboard-layout')
            ->section('dashboard_content');
    }
}
