-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: 127.0.0.1	Database: shopinmy
-- ------------------------------------------------------
-- Server version 	8.4.3
-- Date: Sun, 24 May 2026 12:27:57 +0000

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40101 SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abandoned_carts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abandoned_carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `reminded_at` timestamp NULL DEFAULT NULL,
  `converted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `abandoned_carts_cart_id_foreign` (`cart_id`),
  KEY `abandoned_carts_user_id_foreign` (`user_id`),
  CONSTRAINT `abandoned_carts_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `abandoned_carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abandoned_carts`
--

LOCK TABLES `abandoned_carts` WRITE;
/*!40000 ALTER TABLE `abandoned_carts` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `abandoned_carts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `abandoned_carts` with 0 row(s)
--

--
-- Table structure for table `addresses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_user_id_foreign` (`user_id`),
  CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `addresses` VALUES (1,4,'Default','10, Jalan Ceylon','Kuala Lumpur','50200','Wilayah Persekutuan Kuala Lumpur',1,'2026-05-21 06:11:40','2026-05-21 06:37:46'),(2,1,'Address','10, Jalan Ceylon','Kuala Lumpur','50200','Wilayah Persekutuan Kuala Lumpur',0,'2026-05-21 21:06:32','2026-05-21 21:06:32'),(3,4,'Address','s.b, Anjut, Lor Megah','Kota Kinabalu','88781','Sabah',0,'2026-05-22 00:32:36','2026-05-22 00:32:36');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `addresses` with 3 row(s)
--

--
-- Table structure for table `bank_accounts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_accounts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_accounts`
--

LOCK TABLES `bank_accounts` WRITE;
/*!40000 ALTER TABLE `bank_accounts` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `bank_accounts` VALUES (1,'KL Bank','Jatan Ras','7928798312',NULL,1,0,'2026-05-22 05:40:17','2026-05-22 05:40:17');
/*!40000 ALTER TABLE `bank_accounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `bank_accounts` with 1 row(s)
--

--
-- Table structure for table `banners`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_text_overlay` tinyint(1) NOT NULL DEFAULT '1',
  `youtube_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `html_content` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `show_voucher` tinyint(1) NOT NULL DEFAULT '0',
  `sort` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `banners` VALUES (1,'Test',NULL,'banners/01KS7WJNMFEDYWBTB0PQNW9ZSF.png',NULL,1,NULL,NULL,NULL,NULL,1,0,0,'2026-05-20 04:15:21','2026-05-22 06:04:15'),(2,'Raya Mega Sale 2026',NULL,'https://ui-avatars.com/api/?name=Raya+Sale&background=10b981&color=ffffff&size=1024',NULL,1,NULL,NULL,'/products',NULL,1,0,1,'2026-05-21 02:09:23','2026-05-21 02:09:23'),(3,'New Apple Launch',NULL,'https://ui-avatars.com/api/?name=Apple+Launch&background=111827&color=ffffff&size=1024',NULL,1,NULL,NULL,'/product/iphone-15-pro-max',NULL,1,0,2,'2026-05-21 02:09:23','2026-05-21 02:09:23');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `banners` with 3 row(s)
--

--
-- Table structure for table `brands`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `brands` VALUES (1,'Apple','apple','2026-05-21 02:06:57','2026-05-21 02:06:57'),(2,'Samsung','samsung','2026-05-21 02:06:57','2026-05-21 02:06:57'),(3,'Nike','nike','2026-05-21 02:06:57','2026-05-21 02:06:57'),(4,'Adidas','adidas','2026-05-21 02:06:57','2026-05-21 02:06:57'),(5,'Padini','padini','2026-05-21 02:06:57','2026-05-21 02:06:57'),(6,'Habib','habib','2026-05-21 02:06:57','2026-05-21 02:06:57');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `brands` with 6 row(s)
--

--
-- Table structure for table `bundle_products`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundle_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `bundle_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `qty` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bundle_products_bundle_id_foreign` (`bundle_id`),
  KEY `bundle_products_product_id_foreign` (`product_id`),
  CONSTRAINT `bundle_products_bundle_id_foreign` FOREIGN KEY (`bundle_id`) REFERENCES `bundles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bundle_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundle_products`
--

LOCK TABLES `bundle_products` WRITE;
/*!40000 ALTER TABLE `bundle_products` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `bundle_products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `bundle_products` with 0 row(s)
--

--
-- Table structure for table `bundles`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bundles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bundles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bundles`
--

LOCK TABLES `bundles` WRITE;
/*!40000 ALTER TABLE `bundles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `bundles` VALUES (1,'WFO Starter Pack','wfo-starter-pack','Paket komplit untuk kembali kerja ke kantor dengan gaya kekinian. Lebih hemat!',150.00,1,'2026-05-20 10:03:40','2026-05-20 10:03:40');
/*!40000 ALTER TABLE `bundles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `bundles` with 1 row(s)
--

--
-- Table structure for table `cache`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `cache` VALUES ('commbuildy-cache-setting:banner_carousel_enabled','N;',2094951211),('commbuildy-cache-setting:facebook_url','s:1:\"#\";',2094945947),('commbuildy-cache-setting:footer_tagline','s:0:\"\";',2094945947),('commbuildy-cache-setting:google_client_id','s:72:\"661936474769-6m9ktcc9uq77f7j103p0a2d6s5uu56j1.apps.googleusercontent.com\";',2094936217),('commbuildy-cache-setting:google_client_secret','s:35:\"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\";',2094936217),('commbuildy-cache-setting:help_center_url','s:0:\"\";',2094945947),('commbuildy-cache-setting:instagram_url','s:1:\"#\";',2094945947),('commbuildy-cache-setting:privacy_policy_url','s:0:\"\";',2094945947),('commbuildy-cache-setting:site_description','s:106:\"A next-generation e-commerce platform delivering a seamless, secure, and user-centric shopping experience.\";',2094945947),('commbuildy-cache-setting:site_favicon','s:39:\"settings/01KS89MXKKS2Y0SPJB7G7X6SRH.jpg\";',2094945947),('commbuildy-cache-setting:site_logo','s:39:\"settings/01KS89MXKEN3QNKEWGZY6AM41D.png\";',2094945947),('commbuildy-cache-setting:site_name','s:8:\"ShopinMy\";',2094945947),('commbuildy-cache-setting:store_phone','s:12:\"+60123456789\";',2094945947),('commbuildy-cache-setting:terms_conditions_url','s:0:\"\";',2094945947),('commbuildy-cache-setting:track_order_url','s:0:\"\";',2094945947),('commbuildy-cache-setting:twitter_url','s:1:\"#\";',2094945947),('shopinmy-by-buildyweb-cache-setting:google_client_id','s:72:\"661936474769-6m9ktcc9uq77f7j103p0a2d6s5uu56j1.apps.googleusercontent.com\";',2094972297),('shopinmy-by-buildyweb-cache-setting:google_client_secret','s:35:\"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\";',2094972297);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `cache` with 18 row(s)
--

--
-- Table structure for table `cache_locks`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `cache_locks` with 0 row(s)
--

--
-- Table structure for table `cart_items`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cart_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `variant_id` bigint unsigned DEFAULT NULL,
  `qty` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bundle_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_items_cart_id_foreign` (`cart_id`),
  KEY `cart_items_product_id_foreign` (`product_id`),
  KEY `cart_items_variant_id_foreign` (`variant_id`),
  KEY `cart_items_bundle_id_foreign` (`bundle_id`),
  CONSTRAINT `cart_items_bundle_id_foreign` FOREIGN KEY (`bundle_id`) REFERENCES `bundles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `cart_items_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `cart_items` VALUES (4,4,2,5,1,'2026-05-21 21:05:40','2026-05-21 21:05:40',NULL),(12,10,1,1,1,'2026-05-22 07:06:59','2026-05-22 07:06:59',NULL);
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `cart_items` with 2 row(s)
--

--
-- Table structure for table `carts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `carts_user_id_foreign` (`user_id`),
  KEY `carts_session_id_index` (`session_id`),
  CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `carts` VALUES (4,NULL,1,'2026-05-21 21:05:39','2026-05-21 21:05:39'),(10,NULL,4,'2026-05-22 07:06:59','2026-05-22 07:06:59');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `carts` with 2 row(s)
--

--
-- Table structure for table `categories`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  KEY `categories_parent_id_foreign` (`parent_id`),
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `categories` VALUES (1,NULL,'Electronics','electronics',NULL,NULL,'2026-05-21 02:06:57','2026-05-21 02:06:57'),(2,NULL,'Men\'s Fashion','mens-fashion',NULL,NULL,'2026-05-21 02:06:57','2026-05-21 02:06:57'),(3,NULL,'Women\'s Fashion','womens-fashion',NULL,NULL,'2026-05-21 02:06:57','2026-05-21 02:06:57'),(4,NULL,'Home & Living','home-living',NULL,NULL,'2026-05-21 02:06:57','2026-05-21 02:06:57'),(5,NULL,'Beauty','beauty',NULL,NULL,'2026-05-21 02:06:57','2026-05-21 02:06:57');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `categories` with 5 row(s)
--

--
-- Table structure for table `failed_jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `failed_jobs` with 0 row(s)
--

--
-- Table structure for table `flash_sale_products`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flash_sale_products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flash_sale_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `sale_price` decimal(10,2) NOT NULL,
  `qty` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `flash_sale_products_flash_sale_id_foreign` (`flash_sale_id`),
  KEY `flash_sale_products_product_id_foreign` (`product_id`),
  CONSTRAINT `flash_sale_products_flash_sale_id_foreign` FOREIGN KEY (`flash_sale_id`) REFERENCES `flash_sales` (`id`) ON DELETE CASCADE,
  CONSTRAINT `flash_sale_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sale_products`
--

LOCK TABLES `flash_sale_products` WRITE;
/*!40000 ALTER TABLE `flash_sale_products` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `flash_sale_products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `flash_sale_products` with 0 row(s)
--

--
-- Table structure for table `flash_sales`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flash_sales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `starts_at` timestamp NOT NULL,
  `ends_at` timestamp NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flash_sales_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flash_sales`
--

LOCK TABLES `flash_sales` WRITE;
/*!40000 ALTER TABLE `flash_sales` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `flash_sales` VALUES (1,'Midnight Mega Sale','midnight-mega-sale','Diskon gila-gilaan tengah malam!','2026-05-20 08:58:05','2026-05-22 09:58:05',1,'2026-05-20 09:58:05','2026-05-20 09:58:05');
/*!40000 ALTER TABLE `flash_sales` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `flash_sales` with 1 row(s)
--

--
-- Table structure for table `job_batches`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `job_batches` with 0 row(s)
--

--
-- Table structure for table `jobs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"3eb12ca6-76e7-4419-897a-d00c9b816af0\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"customer@customer.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779356546,\"delay\":null}',0,NULL,1779356546,1779356546),(2,'default','{\"uuid\":\"a73848b1-fe36-498b-83b0-0e26510c35aa\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"customer@customer.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779370666,\"delay\":null}',0,NULL,1779370666,1779370666),(3,'default','{\"uuid\":\"8b7552f7-9a7a-49ab-9fd8-508442bf6225\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:3;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:16:\\\"admin@tokoku.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779422794,\"delay\":null}',0,NULL,1779422794,1779422794),(4,'default','{\"uuid\":\"18ebd4d5-c9a0-473b-8644-fcd41a8aa3e5\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"customer@customer.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779438077,\"delay\":null}',0,NULL,1779438077,1779438077),(5,'default','{\"uuid\":\"f0ca1252-6f33-4dd7-ad31-853ba18adb95\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"customer@customer.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779445506,\"delay\":null}',0,NULL,1779445506,1779445506),(6,'default','{\"uuid\":\"71776f37-b9ed-4b6c-afda-5d655f1c777e\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:6;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"customer@customer.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779446403,\"delay\":null}',0,NULL,1779446403,1779446403),(7,'default','{\"uuid\":\"ce1024a9-ccee-442c-adef-57e6251986a8\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:21:\\\"customer@customer.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779447663,\"delay\":null}',0,NULL,1779447663,1779447663),(8,'default','{\"uuid\":\"8f30218a-f80a-43ab-b821-b82a9fa9623c\",\"displayName\":\"App\\\\Mail\\\\OrderPlaced\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"deleteWhenMissingModels\":false,\"data\":{\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\",\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":18:{s:8:\\\"mailable\\\";O:20:\\\"App\\\\Mail\\\\OrderPlaced\\\":3:{s:5:\\\"order\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:16:\\\"App\\\\Models\\\\Order\\\";s:2:\\\"id\\\";i:8;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:2:\\\"to\\\";a:1:{i:0;a:2:{s:4:\\\"name\\\";N;s:7:\\\"address\\\";s:22:\\\"kikyrestunov@gmail.com\\\";}}s:6:\\\"mailer\\\";s:3:\\\"log\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:12:\\\"messageGroup\\\";N;s:12:\\\"deduplicator\\\";N;s:13:\\\"debounceOwner\\\";s:0:\\\"\\\";s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;}\",\"batchId\":null},\"createdAt\":1779453767,\"delay\":null}',0,NULL,1779453767,1779453767);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `jobs` with 8 row(s)
--

--
-- Table structure for table `loyalty_points`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyalty_points` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `points` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_id` bigint unsigned DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loyalty_points_user_id_foreign` (`user_id`),
  CONSTRAINT `loyalty_points_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyalty_points`
--

LOCK TABLES `loyalty_points` WRITE;
/*!40000 ALTER TABLE `loyalty_points` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `loyalty_points` VALUES (1,2,50,'referral',3,'Referral bonus for inviting Dummy Friend','2026-05-21 01:14:13','2026-05-21 01:14:13');
/*!40000 ALTER TABLE `loyalty_points` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `loyalty_points` with 1 row(s)
--

--
-- Table structure for table `media`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `media` with 0 row(s)
--

--
-- Table structure for table `migrations`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_05_20_063307_create_brands_table',2),(5,'2026_05_20_063307_create_categories_table',2),(6,'2026_05_20_063308_create_products_table',2),(7,'2026_05_20_093730_create_permission_tables',3),(8,'2026_05_20_093731_add_phone_to_users_table',3),(9,'2026_05_20_093732_create_product_variants_table',3),(10,'2026_05_20_093849_create_media_table',3),(11,'2026_05_20_100505_create_addresses_table',4),(12,'2026_05_20_100506_create_bank_accounts_table',4),(13,'2026_05_20_100507_create_carts_table',5),(14,'2026_05_20_100507z_create_cart_items_table',6),(15,'2026_05_20_100508_create_orders_table',6),(16,'2026_05_20_100509z_create_order_items_table',6),(17,'2026_05_20_100510_create_payments_table',6),(18,'2026_05_20_101715_create_flash_sales_table',7),(19,'2026_05_20_101715_create_vouchers_table',7),(20,'2026_05_20_101716_create_banners_table',7),(21,'2026_05_20_101716_create_bundles_table',7),(22,'2026_05_20_101717_create_pages_table',7),(23,'2026_05_20_101717_create_reviews_table',7),(24,'2026_05_20_101718_create_settings_table',7),(25,'2026_05_20_101730_create_bundle_products_table',7),(26,'2026_05_20_101730_create_flash_sale_products_table',7),(27,'2026_05_20_102418_add_guest_and_tax_to_orders_table',8),(28,'2026_05_20_102418_add_rejection_reason_to_payments_table',8),(29,'2026_05_20_102419_add_label_description_to_settings_table',8),(30,'2026_05_20_102419_create_returns_table',8),(31,'2026_05_20_102420_create_loyalty_points_table',8),(32,'2026_05_20_102420_create_return_items_table',8),(33,'2026_05_20_102421_create_product_questions_table',8),(34,'2026_05_20_102421_create_referrals_table',8),(35,'2026_05_20_102421_create_restock_alerts_table',8),(36,'2026_05_20_102422_create_abandoned_carts_table',8),(37,'2026_05_20_102422_create_newsletter_subscribers_table',8),(38,'2026_05_20_110206_add_images_to_products_table',9),(39,'2026_05_20_113525_create_product_images_table',10),(40,'2026_05_20_113525_create_wishlists_table',10),(41,'2026_05_20_160538_alter_carts_table_add_session_id_and_nullable_user',11),(42,'2026_05_20_160904_alter_orders_table_make_user_nullable',12),(43,'2026_05_20_161803_alter_addresses_table_add_is_default',13),(44,'2026_05_20_170053_add_bundle_id_to_cart_and_order_items_table',14),(45,'2026_05_21_080824_add_referral_code_to_users_table',15),(46,'2026_05_21_100441_add_guest_address_columns_to_orders_table',16),(47,'2026_05_21_120000_add_order_number_and_weight_columns',17),(48,'2026_05_22_041752_apply_audit_fixes',18),(49,'2026_05_22_063821_remove_grabpay_setting',19),(50,'2026_05_22_074606_add_stock_to_products_table',19),(51,'2026_05_22_114720_add_google_id_to_users_table',20),(52,'2026_05_22_121133_add_avatar_to_users_table',21),(53,'2026_05_22_130019_create_notifications_table',22),(54,'2026_05_22_130947_add_html_and_youtube_to_banners_table',23),(55,'2026_05_22_132814_make_image_nullable_in_banners_table',24),(56,'2026_05_22_134447_add_dynamic_fields_to_banners_table',25),(57,'2026_05_22_171420_create_wa_templates_table',26),(58,'2026_05_23_224338_make_title_nullable_and_add_overlay_toggle_to_banners_table',27),(59,'2026_05_23_225147_add_mobile_image_to_banners_table',28),(60,'2026_05_24_011215_add_is_public_to_vouchers_table',29),(61,'2026_05_24_011618_add_targeting_to_vouchers_table',30),(62,'2026_05_24_044853_add_courier_rating_to_orders_table',31),(63,'2026_05_24_051453_add_icon_to_categories_table',32),(64,'2026_05_24_052350_add_user_usage_limit_to_vouchers_table',33),(65,'2026_05_24_084457_add_shipping_warranty_to_products_table',34);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `migrations` with 65 row(s)
--

--
-- Table structure for table `model_has_permissions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `model_has_permissions` with 0 row(s)
--

--
-- Table structure for table `model_has_roles`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `model_has_roles` with 1 row(s)
--

--
-- Table structure for table `newsletter_subscribers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter_subscribers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscribed_at` timestamp NULL DEFAULT NULL,
  `unsubscribed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `newsletter_subscribers_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `newsletter_subscribers`
--

LOCK TABLES `newsletter_subscribers` WRITE;
/*!40000 ALTER TABLE `newsletter_subscribers` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `newsletter_subscribers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `newsletter_subscribers` with 0 row(s)
--

--
-- Table structure for table `notifications`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `notifications` VALUES ('b623c98f-3ead-4e82-b62c-d3d9b98f56e4','App\\Notifications\\TestNotification','App\\Models\\User',1,'{\"title\":\"Pesanan Dikonfirmasi!\",\"message\":\"Hore! Pembayaran Anda telah kami terima dan pesanan sedang diproses.\",\"url\":\"http:\\/\\/localhost:8000\\/dashboard\\/orders\",\"icon\":\"ph-check-circle\"}',NULL,'2026-05-22 06:01:21','2026-05-22 06:01:21');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `notifications` with 1 row(s)
--

--
-- Table structure for table `order_items`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `variant_id` bigint unsigned DEFAULT NULL,
  `qty` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `bundle_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  KEY `order_items_variant_id_foreign` (`variant_id`),
  KEY `order_items_bundle_id_foreign` (`bundle_id`),
  CONSTRAINT `order_items_bundle_id_foreign` FOREIGN KEY (`bundle_id`) REFERENCES `bundles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL,
  CONSTRAINT `order_items_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `order_items` VALUES (7,7,1,1,1,5499.00,'2026-05-22 04:01:03','2026-05-22 04:01:03',NULL),(8,8,2,4,1,439.00,'2026-05-22 05:42:47','2026-05-22 05:42:47',NULL);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `order_items` with 2 row(s)
--

--
-- Table structure for table `orders`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `voucher_id` bigint unsigned DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `courier_rating` int DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `shipping_cost` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tax_rate` decimal(5,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `courier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tracking_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `awb_label_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guest_postcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_unique` (`order_number`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_address_id_foreign` (`address_id`),
  KEY `orders_voucher_id_foreign` (`voucher_id`),
  CONSTRAINT `orders_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `orders_voucher_id_foreign` FOREIGN KEY (`voucher_id`) REFERENCES `vouchers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `orders` VALUES (7,'ORD-MOV5ZLV0',4,1,NULL,'processing',NULL,5505.80,6.80,0.00,0.00,'ninjavan','DEMO703952NV',NULL,'customer@customer.com','Mama Rock','+60174632076','10, Jalan Ceylon','Kuala Lumpur','Wilayah Persekutuan Kuala Lumpur','50200','2026-05-22 04:01:03','2026-05-22 04:01:43'),(8,'ORD-S8318IIS',4,3,NULL,'pending',NULL,461.20,22.20,0.00,0.00,'poslaju',NULL,NULL,'kikyrestunov@gmail.com','Rhegysa Alvyanthi Juniartha','+60123456789','s.b, Anjut, Lor Megah','Kota Kinabalu','Sabah','88781','2026-05-22 05:42:47','2026-05-22 05:42:47');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `orders` with 2 row(s)
--

--
-- Table structure for table `pages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `pages` with 0 row(s)
--

--
-- Table structure for table `password_reset_tokens`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `password_reset_tokens` with 0 row(s)
--

--
-- Table structure for table `payments`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `proof_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rejection_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `verified_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_order_id_foreign` (`order_id`),
  KEY `payments_verified_by_foreign` (`verified_by`),
  CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `payments` VALUES (7,7,'manual','manual_transfer','paid',NULL,NULL,5505.80,NULL,NULL,'2026-05-22 04:01:27',4,'2026-05-22 04:01:03','2026-05-22 04:01:27'),(8,8,'manual','manual_transfer','pending',NULL,NULL,461.20,'payment-proofs/GZ4NbBpJSLRjelKilOplyq7VoH5PsBgdLGgCU5Rg.txt',NULL,NULL,NULL,'2026-05-22 05:42:47','2026-05-23 20:03:16');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `payments` with 2 row(s)
--

--
-- Table structure for table `permissions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `permissions` with 0 row(s)
--

--
-- Table structure for table `product_images`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `sort` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_images_product_id_foreign` (`product_id`),
  CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `product_images` with 0 row(s)
--

--
-- Table structure for table `product_questions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_questions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_questions_product_id_foreign` (`product_id`),
  KEY `product_questions_user_id_foreign` (`user_id`),
  CONSTRAINT `product_questions_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_questions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_questions`
--

LOCK TABLES `product_questions` WRITE;
/*!40000 ALTER TABLE `product_questions` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `product_questions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `product_questions` with 0 row(s)
--

--
-- Table structure for table `product_variants`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_variants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_modifier` decimal(10,2) NOT NULL DEFAULT '0.00',
  `stock` int NOT NULL DEFAULT '0',
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variants_product_id_foreign` (`product_id`),
  CONSTRAINT `product_variants_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variants`
--

LOCK TABLES `product_variants` WRITE;
/*!40000 ALTER TABLE `product_variants` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `product_variants` VALUES (1,1,'Storage','256GB - Natural Titanium',0.00,17,NULL,'2026-05-21 02:08:47','2026-05-22 07:58:57'),(2,1,'Storage','512GB - Natural Titanium',1000.00,14,NULL,'2026-05-21 02:08:47','2026-05-22 07:58:57'),(3,1,'Storage','1TB - Natural Titanium',2000.00,15,NULL,'2026-05-21 02:08:47','2026-05-22 07:58:57'),(4,2,'Size','US 8',0.00,29,NULL,'2026-05-21 02:09:23','2026-05-22 05:42:47'),(5,2,'Size','US 9',0.00,39,NULL,'2026-05-21 02:09:23','2026-05-22 01:21:17'),(6,2,'Size','US 10',0.00,30,NULL,'2026-05-21 02:09:23','2026-05-21 02:09:23');
/*!40000 ALTER TABLE `product_variants` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `product_variants` with 6 row(s)
--

--
-- Table structure for table `products`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `brand_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `is_free_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `warranty_period` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `weight` decimal(8,3) NOT NULL DEFAULT '0.500' COMMENT 'Weight in KG',
  `images` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `products` VALUES (1,1,1,'iPhone 15 Pro Max','iphone-15-pro-max','<p>The ultimate iPhone with titanium design.</p>',5499.00,0,NULL,NULL,0.500,'[\"products/01KS833YGQ5R7JYAZ05CVJ4JDY.jpg\", \"products/01KS834NVS4JRPMB7MRTWZ74ZH.jpg\"]',1,NULL,NULL,NULL,'2026-05-21 02:08:47','2026-05-22 07:58:57'),(2,2,3,'Nike Air Force 1 \'07','nike-air-force-1-07','The radiance lives on in the Nike Air Force 1 \'07.',439.00,0,NULL,NULL,0.500,'[\"https://ui-avatars.com/api/?name=Nike+AF1&background=F3F4F6&color=374151&size=512\"]',1,NULL,NULL,NULL,'2026-05-21 02:09:23','2026-05-21 02:09:23'),(3,1,1,'Apple Watch Series 9','apple-watch-series-9','Smarter. Brighter. Mightier.',1899.00,0,NULL,NULL,0.500,'[\"https://ui-avatars.com/api/?name=Watch+S9&background=F3F4F6&color=374151&size=512\"]',1,NULL,NULL,NULL,'2026-05-21 02:09:23','2026-05-21 02:09:23');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `products` with 3 row(s)
--

--
-- Table structure for table `referrals`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `referrals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` bigint unsigned NOT NULL,
  `referee_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reward_given` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referrals_referrer_id_foreign` (`referrer_id`),
  KEY `referrals_referee_id_foreign` (`referee_id`),
  CONSTRAINT `referrals_referee_id_foreign` FOREIGN KEY (`referee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referrals_referrer_id_foreign` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referrals`
--

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `referrals` VALUES (1,2,3,'HAWM6QRC',1,'2026-05-21 01:14:13','2026-05-21 01:14:13');
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `referrals` with 1 row(s)
--

--
-- Table structure for table `restock_alerts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restock_alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `variant_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restock_alerts_product_id_foreign` (`product_id`),
  KEY `restock_alerts_variant_id_foreign` (`variant_id`),
  KEY `restock_alerts_user_id_foreign` (`user_id`),
  CONSTRAINT `restock_alerts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `restock_alerts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `restock_alerts_variant_id_foreign` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restock_alerts`
--

LOCK TABLES `restock_alerts` WRITE;
/*!40000 ALTER TABLE `restock_alerts` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `restock_alerts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `restock_alerts` with 0 row(s)
--

--
-- Table structure for table `return_items`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_id` bigint unsigned NOT NULL,
  `order_item_id` bigint unsigned NOT NULL,
  `qty` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_items_return_id_foreign` (`return_id`),
  KEY `return_items_order_item_id_foreign` (`order_item_id`),
  CONSTRAINT `return_items_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `return_items_return_id_foreign` FOREIGN KEY (`return_id`) REFERENCES `returns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_items`
--

LOCK TABLES `return_items` WRITE;
/*!40000 ALTER TABLE `return_items` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `return_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `return_items` with 0 row(s)
--

--
-- Table structure for table `returns`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `returns` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `returns_order_id_foreign` (`order_id`),
  KEY `returns_user_id_foreign` (`user_id`),
  CONSTRAINT `returns_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `returns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `returns`
--

LOCK TABLES `returns` WRITE;
/*!40000 ALTER TABLE `returns` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `returns` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `returns` with 0 row(s)
--

--
-- Table structure for table `reviews`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `order_id` bigint unsigned DEFAULT NULL,
  `rating` int NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_order_id_foreign` (`order_id`),
  CONSTRAINT `reviews_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `reviews` VALUES (1,4,1,NULL,5,'Great product! Highly recommended. Fast shipping to KL.','2026-05-21 02:09:23','2026-05-21 02:09:23'),(2,4,2,NULL,4,'Great product! Highly recommended. Fast shipping to KL.','2026-05-21 02:09:23','2026-05-21 02:09:23'),(3,4,3,NULL,5,'Great product! Highly recommended. Fast shipping to KL.','2026-05-21 02:09:23','2026-05-21 02:09:23');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `reviews` with 3 row(s)
--

--
-- Table structure for table `role_has_permissions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `role_has_permissions` with 0 row(s)
--

--
-- Table structure for table `roles`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `roles` VALUES (1,'Super Admin','web','2026-05-20 02:41:33','2026-05-20 02:41:33');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `roles` with 1 row(s)
--

--
-- Table structure for table `sessions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `sessions` VALUES ('4d3XfMWf1EuRFVvq2GdBeyadtci551m4kxnxMaUQ',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJtcXNaOHlmWE5LaFRUTk9iT1hlVEIyb200THozT1hhem1TclFzdzRnIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1779585947),('AmQSNqynYGwDdf7LilsazKIYimBlOgscjNsQmbyy',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJ0dFpiU2NxazM2SGYwcHBVMnF6QU9JdVEyQUR5S0lESHdkaUFKSmg0IiwidXJsIjpbXSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwXC9hZG1pblwvbWFuYWdlLXNldHRpbmdzIiwicm91dGUiOiJmaWxhbWVudC5hZG1pbi5wYWdlcy5tYW5hZ2Utc2V0dGluZ3MifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwicGFzc3dvcmRfaGFzaF93ZWIiOiJhMjRkN2RlODc3YmQ3OTgzMjNiNDIxZDJiZDY3OGNmZTY1MTQwMTI5ODg0NzZiYzFmNzcwNDhhZDZiNjY5MDRmIn0=',1779542813),('ghWnAdmPiFl57CXs926UtKVbYUcx1XqMLVSOvuyt',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJKOWc4ejNhdmUyNTJ6YlNBRDVSSG9uODFFVFZYS1RtcUFmMW9GR2RiIiwidXJsIjp7ImludGVuZGVkIjoiaHR0cDpcL1wvbG9jYWxob3N0OjgwMDBcL2FkbWluXC9tYW5hZ2Utc2V0dGluZ3MifSwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwXC9hZG1pblwvbG9naW4iLCJyb3V0ZSI6ImZpbGFtZW50LmFkbWluLmF1dGgubG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1779519884),('gI70qqqQZruleabtuplOK842YLKGXN54u9KheImV',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJvRU1EZTZReWViMmVuQml2dDVFUG5FdTJwVmk1NkZKRXlicXJKc3UxIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1779465474),('LvPTmY1ews6r3uW11qeI8iNTaBRNPfJM6OuJnxIE',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiIwT3J0cmdjOGhtMnA2NHBGZWk4RUV0VEo5aTY2WXNPNHRtaW5hSkt6IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwXC9hZG1pblwvbWFuYWdlLXNldHRpbmdzIiwicm91dGUiOiJmaWxhbWVudC5hZG1pbi5wYWdlcy5tYW5hZ2Utc2V0dGluZ3MifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJ1cmwiOltdLCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwicGFzc3dvcmRfaGFzaF93ZWIiOiJhMjRkN2RlODc3YmQ3OTgzMjNiNDIxZDJiZDY3OGNmZTY1MTQwMTI5ODg0NzZiYzFmNzcwNDhhZDZiNjY5MDRmIiwidGFibGVzIjp7IjJhZmFkNDRjZjNjOTViZjQwZmU1Y2YyNDYxNDNmYmRmX2NvbHVtbnMiOlt7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoiaWQiLCJsYWJlbCI6Ik9yZGVyIElEIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6InVzZXIubmFtZSIsImxhYmVsIjoiUGVsYW5nZ2FuIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6ImNyZWF0ZWRfYXQiLCJsYWJlbCI6IlRhbmdnYWwiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoic3RhdHVzIiwibGFiZWwiOiJTdGF0dXMiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoidG90YWwiLCJsYWJlbCI6IlRvdGFsIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH1dfX0=',1779520357),('O4JOdL0zFZVPDOc01BuHiV7GkCyLea2o1kv12jU6',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJSZ0w1ZjF3OVJQNlhxQ3FLZVJSbUJLUlRGUFEwTXh0S2NwNDBPMHBLIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwXC9hZG1pblwvbWFuYWdlLXNldHRpbmdzIiwicm91dGUiOiJmaWxhbWVudC5hZG1pbi5wYWdlcy5tYW5hZ2Utc2V0dGluZ3MifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJ1cmwiOnsiaW50ZW5kZWQiOiJodHRwOlwvXC9sb2NhbGhvc3Q6ODAwMFwvYWRtaW5cL21hbmFnZS1zZXR0aW5ncyJ9fQ==',1779591222),('oUAumtwqTBUB2Dc12BNOQ6EsTZ8ihs2ZyL0XOUvs',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJTVXh2NllpMGNySW5nZFg4NThCcEhscXZqV2pTT0VNNk1obFA4VDdYIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvbG9jYWxob3N0OjgwMDBcL2FkbWluXC93YS10ZW1wbGF0ZXMiLCJyb3V0ZSI6ImZpbGFtZW50LmFkbWluLnJlc291cmNlcy53YS10ZW1wbGF0ZXMuaW5kZXgifSwidXJsIjpbXSwibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiOjEsInBhc3N3b3JkX2hhc2hfd2ViIjoiYTI0ZDdkZTg3N2JkNzk4MzIzYjQyMWQyYmQ2NzhjZmU2NTE0MDEyOTg4NDc2YmMxZjc3MDQ4YWQ2YjY2OTA0ZiIsInRhYmxlcyI6eyJkZGMxZDA4ZWJlZmE2NTIyOTAzYWIxZjM3YzNjYjhhY19jb2x1bW5zIjpbeyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6InBhcmVudF9pZCIsImxhYmVsIjoiUGFyZW50IGlkIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6Im5hbWUiLCJsYWJlbCI6Ik5hbWUiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoic2x1ZyIsImxhYmVsIjoiU2x1ZyIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjp0cnVlLCJpc1RvZ2dsZWFibGUiOmZhbHNlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOm51bGx9LHsidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJpbWFnZSIsImxhYmVsIjoiSW1hZ2UiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoiY3JlYXRlZF9hdCIsImxhYmVsIjoiQ3JlYXRlZCBhdCIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjpmYWxzZSwiaXNUb2dnbGVhYmxlIjp0cnVlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOnRydWV9LHsidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJ1cGRhdGVkX2F0IiwibGFiZWwiOiJVcGRhdGVkIGF0IiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOmZhbHNlLCJpc1RvZ2dsZWFibGUiOnRydWUsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6dHJ1ZX1dLCIyYWZhZDQ0Y2YzYzk1YmY0MGZlNWNmMjQ2MTQzZmJkZl9jb2x1bW5zIjpbeyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6ImlkIiwibGFiZWwiOiJPcmRlciBJRCIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjp0cnVlLCJpc1RvZ2dsZWFibGUiOmZhbHNlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOm51bGx9LHsidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJ1c2VyLm5hbWUiLCJsYWJlbCI6IlBlbGFuZ2dhbiIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjp0cnVlLCJpc1RvZ2dsZWFibGUiOmZhbHNlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOm51bGx9LHsidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJjcmVhdGVkX2F0IiwibGFiZWwiOiJUYW5nZ2FsIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6InN0YXR1cyIsImxhYmVsIjoiU3RhdHVzIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6InRvdGFsIiwibGFiZWwiOiJUb3RhbCIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjp0cnVlLCJpc1RvZ2dsZWFibGUiOmZhbHNlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOm51bGx9XSwiYTRiYTY0MmM0ZWFkOGFjM2QxY2QyNzMwYmNhZmY2ODlfY29sdW1ucyI6W3sidHlwZSI6ImNvbHVtbiIsIm5hbWUiOiJuYW1lIiwibGFiZWwiOiJOYW1hIFRlbXBsYXRlIiwiaXNIaWRkZW4iOmZhbHNlLCJpc1RvZ2dsZWQiOnRydWUsImlzVG9nZ2xlYWJsZSI6ZmFsc2UsImlzVG9nZ2xlZEhpZGRlbkJ5RGVmYXVsdCI6bnVsbH0seyJ0eXBlIjoiY29sdW1uIiwibmFtZSI6ImV2ZW50X2NvZGUiLCJsYWJlbCI6IktvZGUgRXZlbnQiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoiaXNfYWN0aXZlIiwibGFiZWwiOiJTdGF0dXMiLCJpc0hpZGRlbiI6ZmFsc2UsImlzVG9nZ2xlZCI6dHJ1ZSwiaXNUb2dnbGVhYmxlIjpmYWxzZSwiaXNUb2dnbGVkSGlkZGVuQnlEZWZhdWx0IjpudWxsfSx7InR5cGUiOiJjb2x1bW4iLCJuYW1lIjoiY3JlYXRlZF9hdCIsImxhYmVsIjoiQ3JlYXRlZCBhdCIsImlzSGlkZGVuIjpmYWxzZSwiaXNUb2dnbGVkIjpmYWxzZSwiaXNUb2dnbGVhYmxlIjp0cnVlLCJpc1RvZ2dsZWRIaWRkZW5CeURlZmF1bHQiOnRydWV9XX0sImZpbGFtZW50IjpbXX0=',1779471077);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `sessions` with 7 row(s)
--

--
-- Table structure for table `settings`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'general',
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `settings` VALUES (1,'site_name','Nama Toko','Nama toko yang tampil di header dan email','ShopinMy','general',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(2,'site_email','Email Toko','Email utama toko untuk komunikasi','help@shopinmy.com','general',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(3,'site_phone','Nomor HP Toko','Nomor WhatsApp / HP toko','085806140244','general',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(4,'site_address','Alamat Toko','Alamat fisik toko (origin pengiriman)','JL. DENPASAR NO.18 LINGK KLTAKAN','general',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(5,'sst_enabled','Aktifkan SST','Aktifkan Sales and Services Tax Malaysia','0','sst',0,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(6,'sst_rate','Rate SST (%)','Default: 8%','','sst',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(7,'sst_label','Label Tampil','Label SST yang tampil di invoice','','sst',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(8,'manual_transfer_enabled','Aktifkan Manual Transfer','Customer transfer ke rekening toko','1','payment',0,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(9,'cod_enabled','Aktifkan COD','Bayar di tempat saat kurir tiba','1','payment',0,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(10,'billplz_sandbox','Billplz Sandbox Mode','Aktifkan mode sandbox untuk testing','0','payment',0,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(11,'billplz_api_key','Billplz API Key',NULL,'eyJpdiI6Ik4zVm4yVnVlRlVLSGtUTWFkaDBjQmc9PSIsInZhbHVlIjoibkhyNFNmZXczN0d6aEh6NnUyaU1JUT09IiwibWFjIjoiZTRhODViMjgwMzIwZGYzOGQzNzdhZGQxMTVhZTQ0ODdkOTUwZDQxYWIyMWEwZmY3MDlmNjQxNTdlYjc0MzA4ZSIsInRhZyI6IiJ9','payment',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(12,'billplz_collection_id','Billplz Collection ID',NULL,'','payment',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(13,'billplz_x_signature','Billplz X-Signature',NULL,'eyJpdiI6IlU2d0Q4Tm1kdFRnWTBSRlV2bUNMM2c9PSIsInZhbHVlIjoiQThNWVFFcTQ5VTRjOElXVzJybGxuQT09IiwibWFjIjoiYWNkZmI3MjYxNDk0MDYwM2ViMTU3OTA2OTYxOWRjNzBhMTBjZjQzMTc0MjE0YzIxZmRhZDRmNDY2MTEzNmExZSIsInRhZyI6IiJ9','payment',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(14,'stripe_sandbox','Stripe Test Mode','Aktifkan mode test untuk Stripe','0','payment',0,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(15,'stripe_publishable_key','Stripe Publishable Key',NULL,'','payment',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(16,'stripe_secret_key','Stripe Secret Key',NULL,'eyJpdiI6IlF5RUUyVUcxTEZlMnZENlIxWVp4Z3c9PSIsInZhbHVlIjoiTFRhSTZIMlNML2pYelFpSitQMEtCQT09IiwibWFjIjoiZTkzZDA3MzgwMWEzNzFlMDAyYWVhMDMwMmE4Y2M2OGRiYzhlYjRmZGI4ZWM1YWJmYWI4YTQ4ODg0NzdiYjcwYyIsInRhZyI6IiJ9','payment',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(17,'stripe_webhook_secret','Stripe Webhook Secret',NULL,'eyJpdiI6Ik10OFVRSmZQbDQvRjhwc1VnVjNZREE9PSIsInZhbHVlIjoiMEtURWhtYkM1VEtDNlU5Wm5STmw2QT09IiwibWFjIjoiMTMxODEzZTM4ODg1NTc0OTJmZDYzMGU1MTdjMjM3ZDc3ZGMyNzlkOWExNzA1NDMyZjgxMzAzNTIzOGE5MTlmOSIsInRhZyI6IiJ9','payment',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(18,'easyparcel_sandbox','EasyParcel Sandbox Mode',NULL,'1','shipping',0,'2026-05-20 03:49:44','2026-05-21 02:38:10'),(19,'easyparcel_api_key','EasyParcel API Key',NULL,'eyJpdiI6ImJVTXYwM0JBZWNZM0NRbTNnK1VvRlE9PSIsInZhbHVlIjoidndJWlYrVjFrd2I4eVdnd1k2WUV6Zy94SE9uSFJJMTV1MnVUTlBIVlF4MjQ0ZlRoS1NRS2lLbml2OWwvcktYR09md1JUS3QzRG0rNG80eGt0N21sc3BMcUdtTjlvbGdlMjByWFA3QXByM3JtUkpRb0V6NEx2ZHBNRGx1d1BiWnNFY25xWE5HbmdYUHNUS2RqSnlUVExpOTloRVhDSUVXNkV3QXJMRnZ2S2k0V3JmdVRTY1kzWExyZ0xNQnZ4bTVydy9IanZBMEovcjFWeW5PMGNlNGZROVNzSkpRVmNZWGM2YUQvYm1DWVRURTFZSVY5ZE1ZLzlwbkZjdzVhQk5kbFZtRWQ1WWNEZEpGYXFKbUxla2xCalE9PSIsIm1hYyI6IjM4OGFmMzBmYTM1YzU0YWI0YWM0YzZjM2JjZTQzNjcwNTRkMjZlZmIyNjE2MDgzZDI5ODU2YTE5ODU2NWY4ZmUiLCJ0YWciOiIifQ==','shipping',1,'2026-05-20 03:49:44','2026-05-21 02:38:10'),(20,'store_postcode','Postcode Asal Pengiriman','Postcode lokasi toko','58100','shipping',0,'2026-05-20 03:49:44','2026-05-21 05:57:05'),(21,'store_state','State Asal Pengiriman','State lokasi toko di Malaysia','WP Kuala Lumpur','shipping',0,'2026-05-20 03:49:44','2026-05-21 05:57:05'),(22,'mail_host','SMTP Host',NULL,'','notification',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(23,'mail_port','SMTP Port',NULL,'','notification',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(24,'mail_username','SMTP Username',NULL,'eyJpdiI6IitUSHZsYUs2TjFLK0l6aTdOVFZlekE9PSIsInZhbHVlIjoiYkZselBzN2wzelE2ZjBycnpuOVNNTEtpMGZaU2xXaFFKam4va1pZRWJ5WT0iLCJtYWMiOiI0OGE0YWY0YTM3OGQ0YzVmN2EwNmVjMzQ2OWNlMWU2ZTkxYWRiNGUxZjNiMjNiOGQ0ZGU0YmQxMWIxMTkwZGRmIiwidGFnIjoiIn0=','notification',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(25,'mail_password','SMTP Password',NULL,'eyJpdiI6InNHRFA5SVZrNWF6VFJHUG1XaHBJcXc9PSIsInZhbHVlIjoiaE9mT0dUbG9nRlIzWmJKZXFxVUdwdz09IiwibWFjIjoiZGRkYWE2ZjNjMDcyOGJkNTMxNDUyNDJkOTE2ODE1MjFjMDBlZTk2OGE3ZGYyZDkxNjU2MTdjZTVkNjVlOGE1MyIsInRhZyI6IiJ9','notification',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(26,'mail_from_address','From Email','Alamat email pengirim','','notification',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(27,'mail_from_name','From Name','Nama pengirim email','','notification',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(28,'whatsapp_enabled','Aktifkan WhatsApp Notif',NULL,'0','notification',0,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(29,'fonnte_token','Fonnte Token','Token API Fonnte untuk WhatsApp','eyJpdiI6InIzYVdhalYzTm9wbXVFYkJtdk5hWWc9PSIsInZhbHVlIjoiS1FDbTlTOUltSGtpOENqYksxVnZ6Q1VVbUVudXJTcXUwWW9SdFRjQVRPRHlMR0srNG9CUy9QNG90d0JYZXUwVy9oRlg5bTJHc3VhS2ZMZlJPTENGWGV1aGRjMVEwMXZjY0x2bFlzTHJ5bVowdm90d3Y2c2hkcFh1WGY1SWZrU0VOajJGVU54c0d3T09Ba1YyaUpLeWVLVEkvTDRzNGszdHZZTi83TGh1ZVJ4bzdhdVNseFFKdWlGb2VTdy9yK2pjVkhnU3RxbUs5RXM1MC9kYzh3WXhZMFJDR3liTEhURkRZVHFrTjVVOGhYOVUrZGloQStoSGxNckhvcmd5ZzJzT1Q1bUowYjhTSTZBVUhKWndZSFNOaEVFcEsvV0w3ZjNRYXBUZzJaWDE3cHIvQ05nQjIxS1BZZTA3bDgvZFJlTFZFRm9HWURjSGQ0WEJiMG5IYTkyY1JzRGVaUXYzTjU1eDR5YTN5aVNZYnppUXRNTmxEREVSU0x1UnFFRmdJVk9SbksrSXp3WUJOZzJSSGs1SS81UEpKV1AxUFNVNWNOOFN5Y2ZuNG1FYWdtaWVnM3pnZmliWkRoOG91Y0oybkZwSzVBRkprTDllSUFMTlBMeW8yeXZrb2dwUGE3VkhTUUpmWUtlSzlibVVUQWFLelUzeDlQUmJsNFRuUFh2dS9kamlEWXpJSDQ5V1VMS0w5U3JXQ0xVK1ZLVFV5TFFIMDdDZ1p6MkxOMzc4OU4yZkVBRWc5RmZlY25oSGkyNWFSSGwreEZQUDRzZ3JYOUhqMDBqVFYrdTBHZ05uWVlXeENBUFh5amxTS0ovajhmZkpVSGJabURTNVc4cnJBZ1RsTjNpd2t2SlJUT3VnaEhLa2ZDWGVJV01hWDNmZkgzcGJHNktlS3UrN0ViYzFsU241b1ZCNlpRVDAvR1RCekRkWmEwaHNMYnVxVFNOOWM0L0N2d1RYd3Jub2lueVVETjR1a09QKzU3YUN3UUNjdTdvUi9JN3U3QnpRZ2VPaEh2dndGUFN1ZTNsbm5nUGxzR2xMSGRJWU91UjlZL3RuQzh1RFJ3c2J2bmgyYzFhMlZnV3FITi92WVcrRTRMYnJVenY5bi9OdnN0aHd5SloxU1FHcDdjRnByZjFGQlhXTW95bitjbFgxd29HR2NzYjlNNG54Z21DTGkxN2ZDbVR6T2E5eHFqdk9Xd0VxUHd4cXdaVjcyUkNpVnhyTHNxOUFSdERmSjhIVzNsc3ZSVXpteXFHQmVhY0ZSZVQ4cU9JYy9tTk1DbjdYeUlFK1AvWUsrMVlsdnJ5dVFrdk5tcG9VMjNRU2k4T0szaDI1VlZDR2t1T1NWd1ZlZGF3WDB2ZE13RFpCMkxmakdnMS9rdDFYWllQOGdyNDN6T3ZmZWxnbXdKZDVjYXgyOGF5NGhqSit2SkY5VWlnVXU5VGtNMW1ZeG5saEQwZ3pGdHUzMy80TTh4SkNNbnBRcU1OWlNVeVNiS2hMemdSWjduTnh1SE52SURDSDNnVWUwNU5oRlZjYXBHaDdpQi82cy9sZDhOa3dxWmd3U2hLbTUwNEJuSWVCQXY5TkdYMDR2dndLWFVvWmVpVVYvLy9VeWVxSUE4cFo5b1F5NWNLemtiV0g2NlBiV2dNVHZSN2RmRFBVcldnTUxWNGpTbTlpaWp0dGpNOTR0aHREcERkS3QzSlJLWGVYMTRYVkZVTXEzR1dBaDN6TThwaGtia2NrT3JBcXpSYkF5MCtvekhFN0h5NXN6R093Q2tzWndGWHQ4VkxUT0MzZGd5b2ZEVTJ4aGNjdzg5RnpCVUdOekZHWGlPZzhVNGFDNktlaWM4TFFPLzA2VDVpa09EN2lVbVFHKzlTc1N2bFp5aU5CSVM5RHVycWN5bnViL2hid1pnVU1pdkV2NWViK1E3N09GM3IxVUFkWVE1Qk9INlZJdjRBanBjWEJwOFd5MjJBa1dtMjhXdHAwZitwb0ZsMG9QZmtYUGlWNzZUUmlqQ2RsNXE4bFRHNEdTdUp6azIxa0VuQm02QU81Tm9uVDdybkV3WjVRZzRKOUhzSEpYUWkxNTd1eE5ld095TUtiUlFMQVBLcGxkOGhTUFVrbHJOV09CQkhJM1NOUElYcUo0RFRJQXNhK2xLZFAwZUY4SEw2ckl5S0tCYy9ONi92NmdJSEJTWjYrNzJiVFRyRWZpSURnODJHNHhtbUV1OGZiMW03aFVDWWhyVXQyMk5MSVhBOThZS3B1d1ZFY2FLS3h1ZWsxSWpFVUVlVDhYZmE4eVIvTnhSZS9PVDhSTlBaRVhML25JdmZVUUhvRnZXeFRSVmVSN1RTYlYwU1phNWFZN1FlUVV1WXJZTk9mcjJCK1Z3S0xiRDgremtsL0JPQjdHcHp2bExObklySTBib0k3aUZ6MXp1ckZ6MWxBLzU1TlVKZEdXcVkzRWhoU3BQNVZKaSs4RDd3YzRQRDU4Q1BUcFV3WHJxNXBKUFU3amYzanBIVm9ETWp4YUp0WUcrR3QxVXNyT0hQaFJXU0NMRkJrTklQQjZlZCtlOGJFbG1scVZMRldMRkNVVE1SeUpnYVAzTzM0WjVnYlg5Mm5TR0hrcE85RU9PTGJ2YXNPSjZ6OVVtNHRHTFl0WGYrZU1mcitQZUw2aGtIWFhOWm5rUmltTDNNSFVoSCt1WmlBT0ZnRkNFMTdxYS9Zd2JkZTZ3WkEyaStUOGkrdk44S2NwcTJaV2pxR2h3NVpJSW5Md3Y0UFVRUlV2SGpEYzVHQ1BCUUtYREJ6MWQwZVdLQ3RVdHN4bDd3bEpTdTUwd29TL1NZZDljZWs4RTFGZmc3RlFMbm5MWGpybndSbUJraGpqT2tSUzFXT3pwR1hNMVppeGJaWFVYNUpZQmZZZjN4UjVtbDA4WVpVbkxVMDBLdDRNWnVJeUM0NUVIM2dFZ0ZLc3YxQzVqc0VYRDVacXA3Yk9ScDhUSStHS1hkbmZGdk4yc3NWOWJzdlRxYWMva2tIWDg1b3E3SFdud1M5eU1ZdDY0czJFa3krb2dhblc2eTFjdnN3UFlOVUU5RXIrU04xeW9nRXowKytGclUxYnVTUEZLUVZQaDVFN05DazlRaGR6dHNRdGw2a2luSk01NkRxVjF6TXA3dmVTRVIzNGRNcEZGWEo3OGdmV0daWUhteUt3dXdjdTY3K0tHT2QxSWhGNVE3QmMwMTBmNXFLSTQxVUlxZ1BHNEgxTnc4NkhRVERBSFJpSkR5a0FwUE1ZMzBnZEpCdU0wYXhtMHpHeWkyUHgyRjRVbEl0NERQU1dFMVZWWlM0bDd2MDd2YzNPcW1GVGlYM2ZYWmFWbEllQlFlSU1CQ1c0cVlsQlhKbncyRW1wYTVhQXNXZW1PdmpvUlhsNU1ZRW1XV2w1TzJUTldHOTl5Zk92Nm94b2g1bFFZdGtTTXd2YzVnMkRZa0M3L2E4d3IrU09GQk90d0hhTWFTVVMyVXNjQkJab0RZYVZKMkRvRi9TNjN5Y043bnBrNnJqRWdERURQSEhSVFlkUmJUTVhVOHZBaWJNelM1cy8rbUxmeU1ROHpKZHVLQVNDdHp0b0VEQ2FlNS9hSC9GR0pDdmdVMGVWWlY3VDJWSThSOXFvTTBwSHRuYW16K2lyTjUvSVNMcHNSMWRBcUFJMDZkZjlXTk95QzR4VFBRM1BZclZsUEFkS1cvdUo4YytubnYvT0cwYzFjOFlPSHlFM0lYdVFRRWVnRk9iVlhHVmtqMU5uS1Q1NzlFWTg4QlQ2Zkt6TEg2VThGcGNGUHhKc1dESHlOVDA3SUR1SHErSzBIdTZuMFd5WU5JS3JuNjhXQ21YN2FYd09PQmY0WFppVzB2bFdHZTdSMlRnR0U1SzVDa2NBbnNDbnluNXhPVHlUUWtXK0MvVlhpbXNtdjN5WUczMlIva1V2U2lQeWZTSlNOaTZGeFlmb3RCQzlSVnNxaFBNbDJ2QWM3TFJzVHJxNjB6TitTMmt4aVdMZTk5bnpGSXMzbCt4bS9wbzErRURRSUtVQ3MxY3JXOCtkZmVJRHNtbWViOWcxUjRIMkVhRDJmVWlRYllsUGQwPSIsIm1hYyI6IjBjMDFjNTA3OGI3ZDk0MTlmMGFkYmE1MjQwN2JiYjRhYjIzODVmZjhmN2NmY2Q1Y2M2YTY0MTI1ZGYwZmU2ZDAiLCJ0YWciOiIifQ==','notification',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(30,'fonnte_sender','Nomor WhatsApp Pengirim',NULL,'','notification',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(31,'google_places_api_key','Google Places API Key','Untuk address autocomplete di checkout','eyJpdiI6InIxU0pqMzdIWWRxS253b09NREFXNHc9PSIsInZhbHVlIjoib0lhTFhjcGg2eUxVSklSZzRUeE9PQT09IiwibWFjIjoiY2ExNjQxYzM4NDFlNzAwMjhhZmVlYTkwZmU2ZGQ1YjA0MjY0NjU3NGJmYTEwZjBlZDhjYzMzNWYwZTJjMjVkYiIsInRhZyI6IiJ9','api',1,'2026-05-20 03:49:44','2026-05-22 09:52:40'),(32,'google_analytics_id','Google Analytics ID','G-XXXXXXXXXX','','api',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(33,'facebook_pixel_id','Facebook Pixel ID','Untuk tracking ads Facebook/Meta','','api',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(34,'crisp_website_id','Crisp Website ID','Untuk live chat widget','','api',0,'2026-05-20 03:49:44','2026-05-20 06:00:19'),(35,'site_logo','Logo Toko','Upload logo toko (PNG/SVG)','settings/01KS89MXKEN3QNKEWGZY6AM41D.png','general',0,'2026-05-20 04:59:10','2026-05-22 09:52:40'),(36,'site_favicon','Favicon','Upload favicon (ICO/PNG)','settings/01KS89MXKKS2Y0SPJB7G7X6SRH.jpg','general',0,'2026-05-20 04:59:10','2026-05-22 09:52:40'),(37,'site_language','Bahasa Default','my = Bahasa Malaysia, en = English','en','general',0,'2026-05-20 04:59:10','2026-05-20 04:59:10'),(39,'manual_transfer_deadline_hours','Batas Waktu Upload Bukti (jam)','Order otomatis batal jika tidak upload bukti','24','payment',0,'2026-05-20 04:59:10','2026-05-20 04:59:10'),(40,'myparcel_api_key','MyParcel API Key','API Key dari MyParcel Asia dashboard','eyJpdiI6IjAxcExuYkVLbVJrQXlIbFN3bFRqZ0E9PSIsInZhbHVlIjoiaEhjYnAzSVVWK2Rkb0JQN214QjYxVEs0aUNDMUQ0V1hUcFA3Q25QdHJLcGFjamJodkNPMXlNY1doUUY5NnZlQyIsIm1hYyI6ImRhNTZkNzQ0NTY4ZTg3ODJlNjQ5NzI4YzhjZWQxMTY5MTYwMzBjZDliOTFhNjVlNmRkNDU5NzlkNTJjY2NhYmIiLCJ0YWciOiIifQ==','shipping',1,'2026-05-20 05:33:14','2026-05-22 09:52:40'),(41,'myparcel_api_secret','MyParcel API Secret','API Secret dari MyParcel Asia dashboard','eyJpdiI6IlBIMm90YWt6M3djQlJjZ2g5bGxMMkE9PSIsInZhbHVlIjoiQVJQbjI4ZzlLRDU3WWlvdkpQNktFVk5PUzJrUktsRkZvMUt6QUVZbDEvL0dpYk80RUJBOGFyQldPY2p1MWZ4QiIsIm1hYyI6IjhlNDY4MWNjYzJmODk2OGMwYTgwODE1ZmUwOTM1NzdmNzBlYzU5MTY4YmMxODlkODM0ODdhZDcxMmFiNTcwYTQiLCJ0YWciOiIifQ==','shipping',1,'2026-05-20 05:33:14','2026-05-22 09:52:40'),(42,'myparcel_sandbox','MyParcel Sandbox Mode','Gunakan demo.myparcelasia.com untuk testing','1','shipping',0,'2026-05-20 05:33:14','2026-05-22 09:52:40'),(43,'myparcel_default_provider','Default Courier','poslaju, jnt, ninjavan, citylink, flash, dll','poslaju','shipping',0,'2026-05-20 05:33:14','2026-05-20 05:33:14'),(44,'myparcel_default_size','Default Parcel Size','flyers_s/m/l/xl, box, envelope_a4','flyers_l','shipping',0,'2026-05-20 05:33:14','2026-05-20 05:33:14'),(45,'myparcel_send_method','Send Method','pickup atau dropoff','pickup','shipping',0,'2026-05-20 05:33:14','2026-05-20 05:33:14'),(46,'store_phone',NULL,NULL,'+60123456789','general',0,'2026-05-21 01:22:45','2026-05-21 01:22:45'),(47,'payment_fpx_enabled',NULL,NULL,'0','api',0,'2026-05-21 02:38:10','2026-05-21 02:38:10'),(48,'payment_card_enabled',NULL,NULL,'0','api',0,'2026-05-21 02:38:10','2026-05-21 02:38:10'),(49,'payment_tng_enabled',NULL,NULL,'0','api',0,'2026-05-21 02:38:10','2026-05-21 02:38:10'),(50,'payment_boost_enabled',NULL,NULL,'0','api',0,'2026-05-21 02:38:10','2026-05-21 02:38:10'),(51,'billplz_enabled',NULL,NULL,'0','payment',0,'2026-05-22 04:28:11','2026-05-22 09:52:40'),(52,'stripe_enabled',NULL,NULL,'0','payment',0,'2026-05-22 04:28:11','2026-05-22 09:52:40'),(53,'help_center_url',NULL,NULL,'','general',0,'2026-05-22 04:28:11','2026-05-22 04:28:11'),(54,'terms_conditions_url',NULL,NULL,'','general',0,'2026-05-22 04:28:11','2026-05-22 04:28:11'),(55,'privacy_policy_url',NULL,NULL,'','general',0,'2026-05-22 04:28:11','2026-05-22 04:28:11'),(56,'track_order_url',NULL,NULL,'','general',0,'2026-05-22 04:28:11','2026-05-22 04:28:11'),(57,'newsletter_title',NULL,NULL,'','general',0,'2026-05-22 04:28:11','2026-05-22 04:28:11'),(58,'newsletter_description',NULL,NULL,'','general',0,'2026-05-22 04:28:11','2026-05-22 04:28:11'),(59,'payment_icons',NULL,NULL,'[]','general',0,'2026-05-22 04:30:58','2026-05-22 04:30:58'),(60,'footer_tagline',NULL,NULL,'','general',0,'2026-05-22 04:30:58','2026-05-22 04:30:58'),(61,'google_login_enabled',NULL,NULL,'1','api',0,'2026-05-22 04:53:57','2026-05-22 09:52:40'),(62,'google_client_id',NULL,NULL,'661936474769-6m9ktcc9uq77f7j103p0a2d6s5uu56j1.apps.googleusercontent.com','api',0,'2026-05-22 04:53:57','2026-05-22 07:33:58'),(63,'google_client_secret',NULL,NULL,'eyJpdiI6InlhM1hoc2Mvb2RkU1h4WXo0VzJmWVE9PSIsInZhbHVlIjoiUGZTSStYK2lzZ2xtQTJNeXhGdk9LNkQrdWFpQ0RUb2Rtck9iRk9oTHVMY1NiT21lNGUxSDREc21XY0lTbGpleCIsIm1hYyI6IjI0MTQ4OTBhMDFlNTE4NTA4NzUwN2E0YjQ1MTE3NWFiYWI1NzBjNjk2NWIzZTgwOGY2NDYzMmJiY2Y1ODAzZjEiLCJ0YWciOiIifQ==','api',1,'2026-05-22 04:53:57','2026-05-22 09:52:40'),(64,'loyalty_enabled',NULL,NULL,'0','loyalty',0,'2026-05-22 07:33:58','2026-05-22 09:52:40'),(65,'loyalty_points_per_rm',NULL,NULL,'','loyalty',0,'2026-05-22 07:33:58','2026-05-22 07:33:58'),(66,'referral_enabled',NULL,NULL,'0','loyalty',0,'2026-05-22 07:33:58','2026-05-22 09:52:40'),(67,'referral_reward_points',NULL,NULL,'','loyalty',0,'2026-05-22 07:33:58','2026-05-22 07:33:58');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `settings` with 66 row(s)
--

--
-- Table structure for table `users`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_refresh_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_referral_code_unique` (`referral_code`),
  UNIQUE KEY `users_google_id_unique` (`google_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `users` VALUES (1,'Admin','admin@tokoku.com',NULL,NULL,NULL,'$2y$12$ImLDYaPhU3a0k6V0FyigeuC2y.netFJ5icrToclPVKt4WfwV389Li',NULL,NULL,NULL,NULL,'Ch3mZnMJ8xidryIpH00LILk31AasgsPZBDwSDLuRvQyTvhGMCMluVcqM2QUj','2026-05-19 23:33:49','2026-05-19 23:33:49'),(2,'Admin User','admin@admin.com',NULL,NULL,NULL,'$2y$12$N0KRU27lhigOvWUh3yH85OOAdGRZqlPDOm/t4jkcZ6ysfC.DR2ere',NULL,NULL,NULL,'HAWM6QRC',NULL,'2026-05-21 01:14:13','2026-05-21 01:14:13'),(3,'Dummy Friend','dummy@example.com',NULL,NULL,NULL,'$2y$12$s1CIPbjPx4CJxDtB5KU8AOl3FDCz1LTbJvO6x7efhDHaRVNHX.vQS',NULL,NULL,NULL,'HCSEEEZN',NULL,'2026-05-21 01:14:13','2026-05-21 01:14:13'),(4,'Rhegysa Alvyanthi Juniartha','kikyrestunov@gmail.com','avatars/PRbpZaOnk3RATL4tpBdxIyVdjkcUMdHjYUPaLkQQ.jpg','+60123456789',NULL,'$2y$12$0JN2IZD8ecrsaE0M.cYDFe5M.rhKDtTFT11soP4B9somR4qKr3uam',NULL,NULL,NULL,'AA7WRIFD','yOv3CM4oMQEafuZFaqMU29gNLjPLGls93wOTMV2JdE0ZUqZfNHDmJHGsuo8P','2026-05-21 02:06:37','2026-05-22 05:22:23'),(5,'Kiky Restu Noviansyah','kikyrestunov@stikombanyuwangi.ac.id',NULL,NULL,NULL,'$2y$12$BTipR4mxbJViC4chHHeJJuKooIHwlVH9wENCL8zWbTX/7VWz2fyVu','111227846695714657285','ya29.a0AQvPyIMk4GoLvsXu1KZATNXMbbVi47DOtAyHVrEG8NlR6FBRTfKtdUjTilhtFY8aiorbghVwdI8G9PLaKxG-ecTO-KDWC8IRUxBqYt5PNNH_YAX2u6QZHro0I8BDdrWVye_qVwgzbutj00AG_v3ANl1baxemQEB_oH5vf3zQ3gjhW5YoGfqHpenGEmoRKxWxX_oAibsaCgYKAfcSARMSFQHGX2Miw7S54jXsKIGFw189TvSW4A0206',NULL,'YPJCTEBJ',NULL,'2026-05-22 04:59:00','2026-05-22 04:59:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `users` with 5 row(s)
--

--
-- Table structure for table `vouchers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vouchers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `min_order` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usage_limit` int DEFAULT NULL,
  `user_usage_limit` int DEFAULT NULL,
  `used_count` int NOT NULL DEFAULT '0',
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `is_new_user_only` tinyint(1) NOT NULL DEFAULT '0',
  `target_user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vouchers_code_unique` (`code`),
  KEY `vouchers_target_user_id_foreign` (`target_user_id`),
  CONSTRAINT `vouchers_target_user_id_foreign` FOREIGN KEY (`target_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `vouchers` VALUES (1,'PROMO20','Diskon Spesial Raya','percentage',20.00,100.00,10,NULL,0,'2026-05-25 02:00:00',1,1,0,NULL,'2026-05-22 07:06:29','2026-05-23 18:13:48');
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `vouchers` with 1 row(s)
--

--
-- Table structure for table `wa_templates`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wa_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wa_templates_event_code_unique` (`event_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wa_templates`
--

LOCK TABLES `wa_templates` WRITE;
/*!40000 ALTER TABLE `wa_templates` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `wa_templates` VALUES (1,'OTP','otp_register','Kode Rahasia OTP Anda {otp_code}. Jangan pernah bagikan kode rahasia tersebut kesiapapun.',1,'2026-05-22 10:31:03','2026-05-22 10:31:03');
/*!40000 ALTER TABLE `wa_templates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `wa_templates` with 1 row(s)
--

--
-- Table structure for table `wishlists`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wishlists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_user_id_product_id_unique` (`user_id`,`product_id`),
  KEY `wishlists_product_id_foreign` (`product_id`),
  CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `wishlists` with 0 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET AUTOCOMMIT=@OLD_AUTOCOMMIT */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Sun, 24 May 2026 12:27:57 +0000
