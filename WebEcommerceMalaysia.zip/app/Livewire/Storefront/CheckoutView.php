<?php

namespace App\Livewire\Storefront;

use Livewire\Component;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use Illuminate\Support\Str;

class CheckoutView extends Component
{
    public $cart;
    
    // User Details
    public $name;
    public $email;
    public $phone;
    
    // Shipping Address
    public $address_line;
    public $city;
    public $state;
    public $postcode;
    
    // Payment
    public $payment_method = null; // billplz, stripe, cod, manual_transfer
    
    // Shipping
    public $courier = null;
    public $availableCouriers = [];
    public $isCalculatingShipping = false;
    public $shippingError = null;

    public $subtotal = 0;
    public $shippingCost = 0; // Dynamic rate
    
    public function mount()
    {
        $sessionId = session()->getId();
        $userId = auth()->id();

        $this->cart = Cart::with(['items.product', 'items.variant'])
            ->where(function ($q) use ($userId, $sessionId) {
                if ($userId) {
                    $q->where('user_id', $userId);
                } else {
                    $q->where('session_id', $sessionId)->whereNull('user_id');
                }
            })->first();
            
        if (!$this->cart || $this->cart->items->isEmpty()) {
            return redirect()->route('cart.index');
        }

        // Calculate subtotal
        foreach ($this->cart->items as $item) {
            $price = $item->effective_price;
            $this->subtotal += ($price * $item->qty);
        }

        // Pre-fill user data if logged in
        if (auth()->check()) {
            $user = auth()->user();
            $this->name = $user->name;
            $this->email = $user->email;
            $this->phone = $user->phone ?? '';
        }
    }

    public function updatedPostcode($value)
    {
        if (strlen(trim($value)) >= 5) {
            $this->calculateShipping();
        } else {
            $this->availableCouriers = [];
            $this->shippingCost = 0;
            $this->courier = null;
            $this->shippingError = null;
        }
    }

    public function updatedCourier($value)
    {
        if ($value && isset($this->availableCouriers[$value])) {
            $this->shippingCost = $this->availableCouriers[$value]['price'];
        }
    }

    public function calculateShipping()
    {
        $this->isCalculatingShipping = true;
        $this->shippingError = null;
        
        try {
            $storePostcode = \App\Models\Setting::get('store_postcode');
            
            if (!$storePostcode) {
                $this->shippingError = 'Store origin postcode is not configured.';
                $this->isCalculatingShipping = false;
                return;
            }

            // Calculate total weight
            $totalWeight = 0;
            foreach ($this->cart->items as $item) {
                $weight = $item->product->weight ?? 0.500;
                $totalWeight += ($weight * $item->qty);
            }

            // Fallback if weight is zero
            if ($totalWeight <= 0) $totalWeight = 0.500;

            $myParcel = app(\App\Services\MyParcelService::class);
            $rates = $myParcel->checkPrice($storePostcode, $this->postcode, $totalWeight);
            
            // Reformat rates to a friendly array
            $this->availableCouriers = [];
            
            $prices = $rates['prices'] ?? (isset($rates[0]) ? $rates : []);
            
            if (!empty($prices) && is_array($prices)) {
                foreach ($prices as $rate) {
                    // check_price returns provider_label and effective_price/normal_price
                    if (isset($rate['provider_code'], $rate['provider_label'])) {
                        $price = $rate['effective_price'] ?? $rate['normal_price'] ?? 0;
                        $this->availableCouriers[$rate['provider_code']] = [
                            'name' => $rate['provider_label'],
                            'price' => (float) $price,
                        ];
                    }
                }
            } else {
                $this->shippingError = 'No shipping couriers available for this postcode.';
            }

            if (!empty($this->availableCouriers)) {
                // Auto-select first available or default from settings
                $defaultProvider = \App\Models\Setting::get('myparcel_default_provider');
                if ($defaultProvider && isset($this->availableCouriers[$defaultProvider])) {
                    $this->courier = $defaultProvider;
                } else {
                    $firstCourier = array_key_first($this->availableCouriers);
                    $this->courier = $firstCourier;
                }
                
                $this->shippingCost = $this->availableCouriers[$this->courier]['price'];
            }

        } catch (\Exception $e) {
            $this->shippingError = 'Failed to fetch rates: ' . $e->getMessage();
            $this->availableCouriers = [];
        }

        $this->isCalculatingShipping = false;
    }

    public function placeOrder()
    {
        $this->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:20',
            'address_line' => 'required|string|max:255',
            'city' => 'required|string|max:100',
            'state' => 'required|string|max:100',
            'postcode' => 'required|string|max:20',
            'payment_method' => 'required|in:billplz,stripe,cod,manual_transfer',
            'courier' => 'required',
        ]);

        // Stock validation before transaction
        foreach ($this->cart->items as $item) {
            $productStock = $item->product->stock ?? 0;
            $variantStock = $item->variant ? $item->variant->stock : null;
            
            if ($productStock < $item->qty) {
                $this->addError('cart', "Product '{$item->product->name}' is out of stock.");
                return;
            }
            if ($variantStock !== null && $variantStock < $item->qty) {
                $this->addError('cart', "Variant '{$item->variant->value}' for '{$item->product->name}' is out of stock.");
                return;
            }
        }

        $grandTotal = $this->subtotal + $this->shippingCost;
        
        $addressId = null;

        if (auth()->check()) {
            $address = \App\Models\Address::firstOrCreate(
                [
                    'user_id' => auth()->id(),
                    'address' => $this->address_line,
                    'city' => $this->city,
                    'state' => $this->state,
                    'postcode' => $this->postcode,
                ],
                ['label' => 'Address']
            );
            $addressId = $address->id;
        }

        try {
            $order = \Illuminate\Support\Facades\DB::transaction(function () use ($grandTotal, $addressId) {
                // Generate Unique Order Number
                $orderNumber = null;
                do {
                    $orderNumber = 'ORD-' . strtoupper(Str::random(8));
                } while (Order::where('order_number', $orderNumber)->exists());

                // 1. Create Order
                $order = Order::create([
                    'user_id' => auth()->id(), // null for guests
                    'address_id' => $addressId,
                    'guest_name' => auth()->check() ? null : $this->name,
                    'guest_email' => auth()->check() ? null : $this->email,
                    'guest_phone' => auth()->check() ? null : $this->phone,
                    'guest_address' => auth()->check() ? null : $this->address_line,
                    'guest_city' => auth()->check() ? null : $this->city,
                    'guest_state' => auth()->check() ? null : $this->state,
                    'guest_postcode' => auth()->check() ? null : $this->postcode,
                    'status' => 'pending',
                    'total' => $grandTotal,
                    'shipping_cost' => $this->shippingCost,
                    'courier' => $this->availableCouriers[$this->courier]['name'] ?? $this->courier,
                    'tax_rate' => 0,
                    'tax_amount' => 0,
                    'order_number' => $orderNumber,
                ]);

                // 2. Create Order Items & Decrement Stock
                foreach ($this->cart->items as $item) {
                    $price = $item->effective_price;

                    OrderItem::create([
                        'order_id' => $order->id,
                        'product_id' => $item->product_id,
                        'variant_id' => $item->variant_id,
                        'bundle_id' => $item->bundle_id,
                        'qty' => $item->qty,
                        'price' => $price,
                    ]);

                    // Decrement stock
                    $item->product->decrement('stock', $item->qty);
                    if ($item->variant) {
                        $item->variant->decrement('stock', $item->qty);
                    }
                }

                // 3. Create Payment record
                $paymentType = in_array($this->payment_method, ['cod', 'manual_transfer']) ? 'manual' : 'gateway';
                Payment::create([
                    'order_id' => $order->id,
                    'type' => $paymentType,
                    'method' => $this->payment_method,
                    'amount' => $grandTotal,
                    'status' => 'pending', // Would be 'success' after gateway callback
                ]);

                // 4. Delete Cart
                $this->cart->delete();

                return $order;
            });

            $this->dispatch('cart-updated');

            // Send Email (outside transaction)
            $recipientEmail = auth()->check() ? auth()->user()->email : $this->email;
            try {
                \Illuminate\Support\Facades\Mail::to($recipientEmail)->send(new \App\Mail\OrderPlaced($order));
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::error("Failed to send order email: " . $e->getMessage());
            }

            // Save session for guest so they can access success page
            if (!auth()->check()) {
                session()->put('last_order_id', $order->id);
            }

            // Payment Gateway redirect
            if (in_array($this->payment_method, ['billplz', 'stripe'])) {
                // Redirect to a placeholder payment processing route for now
                return redirect()->route('payment.process', ['order' => $order->id]);
            }

            // 5. Redirect to success page for COD/Manual
            return redirect()->route('checkout.success', ['order' => $order->id]);

        } catch (\Exception $e) {
            $this->addError('cart', "Failed to place order: " . $e->getMessage());
            return;
        }
    }

    public function render()
    {
        return view('livewire.storefront.checkout-view')
            ->extends('layouts.storefront')
            ->section('content');
    }
}
