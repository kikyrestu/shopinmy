<?php

namespace App\Livewire\Storefront;

use Livewire\Component;

class CartView extends Component
{
    public $cart;

    public function mount()
    {
        $this->loadCart();
    }

    public function loadCart()
    {
        $sessionId = session()->getId();
        $userId = auth()->id();

        $this->cart = \App\Models\Cart::with(['items.product.primaryImage', 'items.variant'])
            ->where(function ($q) use ($userId, $sessionId) {
                if ($userId) {
                    $q->where('user_id', $userId);
                } else {
                    $q->where('session_id', $sessionId)->whereNull('user_id');
                }
            })->first();
    }

    public function increment($itemId)
    {
        if ($this->cart) {
            $item = $this->cart->items()->with(['product', 'variant'])->find($itemId);
            if ($item) {
                // Check stock logic
                $productStock = $item->product->stock ?? 0;
                $variantStock = $item->variant ? $item->variant->stock : null;
                
                $maxStock = $variantStock !== null ? $variantStock : $productStock;
                
                if ($item->qty < $maxStock) {
                    $item->increment('qty');
                    $this->loadCart();
                    $this->dispatch('cart-updated');
                } else {
                    $this->dispatch('notify', message: __('Maximum stock reached.'));
                }
            }
        }
    }

    public function decrement($itemId)
    {
        if ($this->cart) {
            $item = $this->cart->items()->find($itemId);
            if ($item && $item->qty > 1) {
                $item->decrement('qty');
                $this->loadCart();
                $this->dispatch('cart-updated');
            }
        }
    }

    public function removeItem($itemId)
    {
        if ($this->cart) {
            $this->cart->items()->where('id', $itemId)->delete();
            $this->loadCart();
            $this->dispatch('cart-updated');
        }
    }

    public function render()
    {
        $subtotal = 0;
        
        if ($this->cart) {
            foreach ($this->cart->items as $item) {
                $price = $item->effective_price;
                $subtotal += ($price * $item->qty);
            }
        }

        return view('livewire.storefront.cart-view', compact('subtotal'))
            ->extends('layouts.storefront')
            ->section('content');
    }
}
