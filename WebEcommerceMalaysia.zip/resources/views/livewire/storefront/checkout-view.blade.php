<div>
    @section('title', __('Secure Checkout'))

    <div class="bg-gray-50 py-6 border-b border-gray-100">
        <div class="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
            <nav class="flex text-sm text-gray-500 font-medium">
                <ol class="flex items-center space-x-2">
                    <li><a href="{{ route('cart.index') }}" class="hover:text-brand-600 transition-colors">{{ __('Shopping Cart') }}</a></li>
                    <li><span class="mx-2">/</span></li>
                    <li class="text-gray-900">{{ __('Checkout') }}</li>
                </ol>
            </nav>
        </div>
    </div>

    <main class="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <h1 class="text-3xl font-extrabold text-gray-900 mb-8">{{ __('Secure Checkout') }}</h1>

        <form wire:submit.prevent="placeOrder" class="flex flex-col lg:flex-row gap-8">
            <!-- Left: Checkout Forms -->
            <div class="flex-1 space-y-8">
                
                <!-- Contact Info -->
                <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 sm:p-8">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <i class="ph-fill ph-user text-brand-500"></i> {{ __('Contact Information') }}
                    </h2>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('Full Name') }}</label>
                            <input type="text" wire:model="name" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('name') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('Phone Number') }}</label>
                            <input type="text" wire:model="phone" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('phone') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                        <div class="sm:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('Email Address') }}</label>
                            <input type="email" wire:model="email" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('email') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                <!-- Shipping Address -->
                <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 sm:p-8">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <i class="ph-fill ph-map-pin text-brand-500"></i> {{ __('Shipping Address') }}
                    </h2>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="sm:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('Street Address') }}</label>
                            <input type="text" wire:model="address_line" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('address_line') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('City') }}</label>
                            <input type="text" wire:model="city" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('city') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('State') }}</label>
                            <input type="text" wire:model="state" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('state') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('Postcode') }}</label>
                            <input type="text" wire:model.live.debounce.500ms="postcode" required class="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:bg-white focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all">
                            @error('postcode') <span class="text-red-500 text-xs mt-1">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                <!-- Shipping Courier -->
                <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 sm:p-8">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <i class="ph-fill ph-truck text-brand-500"></i> {{ __('Shipping Courier') }}
                    </h2>
                    
                    @if($isCalculatingShipping)
                        <div class="flex items-center gap-3 text-gray-500 py-4">
                            <i class="ph-bold ph-spinner animate-spin text-xl text-brand-500"></i>
                            <span>{{ __('Calculating shipping rates...') }}</span>
                        </div>
                    @elseif($shippingError)
                        <div class="bg-red-50 text-red-600 p-4 rounded-xl text-sm">
                            {{ $shippingError }}
                        </div>
                    @elseif(empty($availableCouriers))
                        <div class="text-gray-500 text-sm">
                            {{ __('Please enter your postcode to see available shipping options.') }}
                        </div>
                    @else
                        <div class="space-y-3">
                            @foreach($availableCouriers as $code => $rate)
                                <label class="flex items-center justify-between p-4 border-2 rounded-xl cursor-pointer transition-all {{ $courier === $code ? 'border-brand-500 bg-brand-50/50' : 'border-gray-100 hover:border-gray-200' }}">
                                    <div class="flex items-center gap-3">
                                        <input type="radio" name="courier" wire:model.live="courier" value="{{ $code }}" class="w-5 h-5 text-brand-600 focus:ring-brand-500">
                                        <span class="font-bold text-gray-900">{{ $rate['name'] }}</span>
                                    </div>
                                    <div class="font-bold text-brand-600">RM {{ number_format($rate['price'], 2) }}</div>
                                </label>
                            @endforeach
                        </div>
                        @error('courier') <span class="text-red-500 text-xs mt-2 block">{{ $message }}</span> @enderror
                    @endif
                </div>

                <!-- Payment Method -->
                <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 sm:p-8">
                    <h2 class="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                        <i class="ph-fill ph-credit-card text-brand-500"></i> {{ __('Payment Method') }}
                    </h2>
                    
                    <div class="space-y-3">
                        <!-- Billplz (FPX) -->
                        @if(\App\Models\Setting::get('billplz_api_key'))
                        <label class="flex items-center justify-between p-4 border-2 rounded-xl cursor-pointer transition-all {{ $payment_method === 'billplz' ? 'border-brand-500 bg-brand-50/50' : 'border-gray-100 hover:border-gray-200' }}">
                            <div class="flex items-center gap-3">
                                <input type="radio" name="payment_method" wire:model="payment_method" value="billplz" class="w-5 h-5 text-brand-600 focus:ring-brand-500">
                                <span class="font-bold text-gray-900">FPX Online Banking (Billplz)</span>
                            </div>
                            <div class="font-bold text-blue-800 italic">FPX</div>
                        </label>
                        @endif
                        
                        <!-- Stripe -->
                        @if(\App\Models\Setting::get('stripe_publishable_key'))
                        <label class="flex items-center justify-between p-4 border-2 rounded-xl cursor-pointer transition-all {{ $payment_method === 'stripe' ? 'border-brand-500 bg-brand-50/50' : 'border-gray-100 hover:border-gray-200' }}">
                            <div class="flex items-center gap-3">
                                <input type="radio" name="payment_method" wire:model="payment_method" value="stripe" class="w-5 h-5 text-brand-600 focus:ring-brand-500">
                                <span class="font-bold text-gray-900">Credit / Debit Card (Stripe)</span>
                            </div>
                            <div class="flex gap-1 text-gray-400">
                                <i class="ph-fill ph-stripe-logo text-2xl"></i>
                            </div>
                        </label>
                        @endif

                        <!-- Manual Transfer -->
                        @if(\App\Models\Setting::get('manual_transfer_enabled'))
                        <label class="flex items-center justify-between p-4 border-2 rounded-xl cursor-pointer transition-all {{ $payment_method === 'manual_transfer' ? 'border-brand-500 bg-brand-50/50' : 'border-gray-100 hover:border-gray-200' }}">
                            <div class="flex items-center gap-3">
                                <input type="radio" name="payment_method" wire:model="payment_method" value="manual_transfer" class="w-5 h-5 text-brand-600 focus:ring-brand-500">
                                <span class="font-bold text-gray-900">Manual Bank Transfer</span>
                            </div>
                        </label>
                        @endif
                        
                        <!-- COD -->
                        @if(\App\Models\Setting::get('cod_enabled'))
                        <label class="flex items-center justify-between p-4 border-2 rounded-xl cursor-pointer transition-all {{ $payment_method === 'cod' ? 'border-brand-500 bg-brand-50/50' : 'border-gray-100 hover:border-gray-200' }}">
                            <div class="flex items-center gap-3">
                                <input type="radio" name="payment_method" wire:model="payment_method" value="cod" class="w-5 h-5 text-brand-600 focus:ring-brand-500">
                                <span class="font-bold text-gray-900">Cash on Delivery</span>
                            </div>
                            <i class="ph-fill ph-money text-2xl text-emerald-500"></i>
                        </label>
                        @endif
                    </div>
                    @error('payment_method') <span class="text-red-500 text-xs mt-2 block">{{ $message }}</span> @enderror
                </div>

            </div>

            <!-- Right: Order Summary -->
            <div class="w-full lg:w-96 flex-shrink-0">
                <div class="bg-white rounded-3xl border border-gray-100 p-6 shadow-sm sticky top-28">
                    <h2 class="text-lg font-bold text-gray-900 mb-6">{{ __('Order Summary') }}</h2>
                    
                    <ul class="space-y-4 mb-6">
                        @foreach($cart->items as $item)
                        <li class="flex gap-4">
                            <div class="w-16 h-16 bg-gray-50 rounded-xl overflow-hidden flex-shrink-0 border border-gray-100 relative">
                                @if($item->product->primaryImage)
                                    <img src="{{ asset($item->product->primaryImage->path) }}" class="w-full h-full object-cover">
                                @else
                                    <i class="ph ph-image text-gray-300 w-full h-full flex items-center justify-center"></i>
                                @endif
                                <span class="absolute -top-1 -right-1 w-5 h-5 bg-gray-900 text-white text-[10px] font-bold rounded-full flex items-center justify-center">{{ $item->qty }}</span>
                            </div>
                            <div class="flex-1 text-sm">
                                <div class="font-bold text-gray-900 line-clamp-2">{{ $item->product->name }}</div>
                                @if($item->variant)
                                    <div class="text-gray-500 mt-0.5">{{ $item->variant->value }}</div>
                                @endif
                            </div>
                            @php
                                $price = $item->effective_price;
                            @endphp
                            <div class="font-bold text-gray-900">RM {{ number_format($price * $item->qty, 2) }}</div>
                        </li>
                        @endforeach
                    </ul>

                    <hr class="border-gray-100 mb-6">

                    <div class="space-y-3 text-sm mb-6">
                        <div class="flex justify-between items-center text-gray-600 font-medium">
                            <span>{{ __('Subtotal') }}</span>
                            <span class="text-gray-900 font-bold">RM {{ number_format($subtotal, 2) }}</span>
                        </div>
                        <div class="flex justify-between items-center text-gray-600 font-medium">
                            <span>{{ __('Shipping') }} {{ $courier && isset($availableCouriers[$courier]) ? '(' . $availableCouriers[$courier]['name'] . ')' : '' }}</span>
                            <span class="text-gray-900 font-bold">RM {{ number_format($shippingCost, 2) }}</span>
                        </div>
                        <div class="flex justify-between items-end pt-4 border-t border-gray-100 mt-2">
                            <span class="text-base font-bold text-gray-900">{{ __('Total') }}</span>
                            <span class="text-2xl font-extrabold text-brand-600">RM {{ number_format($subtotal + $shippingCost, 2) }}</span>
                        </div>
                    </div>

                    <button type="submit" class="w-full py-4 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-brand-500/30 transform active:scale-95 text-lg" wire:loading.attr="disabled">
                        <span wire:loading.remove>{{ __('Place Order') }}</span>
                        <span wire:loading>{{ __('Processing...') }}</span>
                        <i class="ph-bold ph-arrow-right" wire:loading.remove></i>
                    </button>
                    
                    <p class="text-center text-xs text-gray-400 mt-4 px-2">
                        {{ __('By placing your order, you agree to our Terms & Conditions and Privacy Policy.') }}
                    </p>
                </div>
            </div>
        </form>
    </main>
</div>
