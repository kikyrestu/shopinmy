<?php

namespace App\Providers;

use App\Models\Setting;
use App\Observers\SettingObserver;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Setting::observe(SettingObserver::class);

        \Illuminate\Support\Facades\View::composer('layouts.storefront', function ($view) {
            $view->with('categories', \App\Models\Category::whereNull('parent_id')->get());
            $view->with('footerPages', \App\Models\Page::select('title', 'slug')->get());
        });
    }
}
