<?php

namespace App\Livewire\Storefront\Dashboard;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Order;

class OrderHistory extends Component
{
    use WithPagination;

    public function render()
    {
        $orders = Order::where('user_id', auth()->id())
            ->with(['items.product'])
            ->latest()
            ->paginate(10);

        return view('livewire.storefront.dashboard.orders', compact('orders'))
            ->extends('components.dashboard-layout')
            ->section('dashboard_content');
    }
}
