<div>
    @section('title', __('Track Package'))

    <div class="bg-gray-50 py-6 border-b border-gray-100">
        <div class="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
            <nav class="flex text-sm text-gray-500 font-medium">
                <ol class="flex items-center space-x-2">
                    <li><a href="{{ route('dashboard') }}" class="hover:text-brand-600 transition-colors">{{ __('Dashboard') }}</a></li>
                    <li><span class="mx-2">/</span></li>
                    <li><a href="{{ route('dashboard.orders') }}" class="hover:text-brand-600 transition-colors">{{ __('My Orders') }}</a></li>
                    <li><span class="mx-2">/</span></li>
                    <li class="text-gray-900">{{ __('Track Package') }}</li>
                </ol>
            </nav>
        </div>
    </div>

    <main class="max-w-3xl mx-auto px-4 sm:px-6 py-10">
        <div class="flex items-center gap-4 mb-8">
            <a href="{{ route('dashboard.orders') }}" class="w-10 h-10 bg-white border border-gray-200 rounded-full flex items-center justify-center text-gray-500 hover:text-brand-600 hover:border-brand-500 transition-all shadow-sm flex-shrink-0">
                <i class="ph-bold ph-arrow-left text-lg"></i>
            </a>
            <div>
                <h1 class="text-2xl font-extrabold text-gray-900">{{ __('Track Package') }}</h1>
                <p class="text-sm text-gray-500">{{ __('Order Number') }}: <span class="font-bold text-gray-900">{{ $order->order_number }}</span></p>
            </div>
        </div>

        <div class="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 sm:p-8">
            @if($isLoading)
                <div class="py-12 text-center text-gray-500">
                    <i class="ph-bold ph-spinner animate-spin text-3xl text-brand-500 mb-4 inline-block"></i>
                    <p>{{ __('Loading tracking information...') }}</p>
                </div>
            @elseif($error)
                <div class="bg-red-50 text-red-600 p-6 rounded-2xl text-center">
                    <i class="ph-fill ph-warning-circle text-3xl mb-2"></i>
                    <p class="font-medium">{{ $error }}</p>
                    @if($order->tracking_no && !str_starts_with($order->tracking_no, 'ORD-'))
                        <div class="mt-4 pt-4 border-t border-red-200">
                            <span class="text-sm">{{ __('Tracking Number') }}:</span>
                            <span class="font-bold block text-lg">{{ $order->tracking_no }}</span>
                            <span class="text-sm mt-1 block">{{ __('Courier') }}: {{ $order->courier ?? 'Unknown' }}</span>
                        </div>
                    @endif
                </div>
            @else
                <div class="flex flex-col sm:flex-row gap-6 justify-between items-start sm:items-center p-6 bg-gray-50 rounded-2xl mb-8">
                    <div>
                        <div class="text-sm text-gray-500 mb-1">{{ __('Tracking Number') }}</div>
                        <div class="text-xl font-extrabold text-gray-900">{{ $order->tracking_no }}</div>
                    </div>
                    <div class="text-left sm:text-right">
                        <div class="text-sm text-gray-500 mb-1">{{ __('Courier') }}</div>
                        <div class="text-lg font-bold text-brand-600 uppercase">{{ $order->courier }}</div>
                    </div>
                </div>

                <div class="relative pl-6 sm:pl-8 border-l-2 border-gray-100 ml-4 sm:ml-6 space-y-8">
                    @foreach($trackingData as $index => $event)
                        <div class="relative">
                            <div class="absolute -left-[35px] sm:-left-[43px] w-6 h-6 sm:w-8 sm:h-8 rounded-full border-4 {{ $index === 0 ? 'bg-brand-500 border-white shadow-md' : 'bg-gray-200 border-white' }} flex items-center justify-center">
                                @if($index === 0)
                                    <div class="w-2 h-2 bg-white rounded-full"></div>
                                @endif
                            </div>
                            <div>
                                <div class="font-bold {{ $index === 0 ? 'text-gray-900' : 'text-gray-600' }}">{{ $event['status'] ?? 'Updated' }}</div>
                                <div class="text-sm {{ $index === 0 ? 'text-gray-700' : 'text-gray-500' }} mt-1">{{ $event['description'] ?? '' }}</div>
                                <div class="text-xs text-gray-400 mt-2 font-medium flex items-center gap-1.5">
                                    <i class="ph-bold ph-clock"></i>
                                    {{ isset($event['date']) ? \Carbon\Carbon::parse($event['date'])->format('d M Y, H:i') : '' }}
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>
    </main>
</div>
